package roadgraph;

import geography.GeographicPoint;

class Route {
	GeographicPoint to;
	String roadName, roadType;
	double length;
	
	public Route(GeographicPoint to,String roadName, String roadType, double length){
		this.to = to;
		this.roadName = roadName;
		this.roadType = roadType;
		this.length = length;
		
	}
	
	
	

}
