package roadgraph;

import geography.GeographicPoint;

class VisitedNode {
	
	VisitedNode parent;
	GeographicPoint gpNode;
	
	public VisitedNode(GeographicPoint gpNode, VisitedNode p){
		this.gpNode = gpNode;
		this.parent = p;
		
	}
}
